function openPages() {
    //Halaman Kode
    if (openPages == "code"){
        
    } 
}
  