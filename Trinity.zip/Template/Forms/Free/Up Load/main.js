let Video = document.getElementById("Video")
let Link = document.getElementById("URL")
let URL = document.getElementById("txtURL")

function masuk () {
    Video.src = Link.value;
    Video.autoplay = true;
    Video.fullscreen = true;
    URL.value = Link.value;
}