let Video = document.getElementById("Video")
let Link = document.getElementById("URL")

function masuk () {
    Video.src = Link.value;
    Video.autoplay = true;
    Video.fullscreen = true;
}

function loop(){
    Video.loop
}