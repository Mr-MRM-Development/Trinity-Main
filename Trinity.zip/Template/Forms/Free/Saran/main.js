function masuk() {
    let id = document.getElementById("ID")
    let pwd = document.getElementById("PWD")
    let saran = document.getElementById("saran")

    if (masuk){
        console.log("ID : " +id.value)
        console.log("Password : " +pwd.value)
        console.log("Saran : " +saran.value)  
    }
}